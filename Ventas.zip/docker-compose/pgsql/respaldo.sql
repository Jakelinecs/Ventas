--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

-- Started on 2023-06-22 15:43:44

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 226 (class 1259 OID 26859)
-- Name: blogs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blogs (
    id bigint NOT NULL,
    titulo character varying(191) NOT NULL,
    contenido text NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.blogs OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 26858)
-- Name: blogs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blogs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blogs_id_seq OWNER TO postgres;

--
-- TOC entry 3517 (class 0 OID 0)
-- Dependencies: 225
-- Name: blogs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blogs_id_seq OWNED BY public.blogs.id;


--
-- TOC entry 232 (class 1259 OID 26886)
-- Name: categorias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categorias (
    id bigint NOT NULL,
    nombre character varying(50) NOT NULL,
    descripcion character varying(256),
    estado boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.categorias OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 26885)
-- Name: categorias_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categorias_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categorias_id_seq OWNER TO postgres;

--
-- TOC entry 3518 (class 0 OID 0)
-- Dependencies: 231
-- Name: categorias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categorias_id_seq OWNED BY public.categorias.id;


--
-- TOC entry 230 (class 1259 OID 26875)
-- Name: cotacto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cotacto (
    id bigint NOT NULL,
    nombre character varying(191) NOT NULL,
    email character varying(191) NOT NULL,
    telefono character varying(191) NOT NULL,
    mensaje text NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.cotacto OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 26874)
-- Name: cotacto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cotacto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cotacto_id_seq OWNER TO postgres;

--
-- TOC entry 3519 (class 0 OID 0)
-- Dependencies: 229
-- Name: cotacto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cotacto_id_seq OWNED BY public.cotacto.id;


--
-- TOC entry 238 (class 1259 OID 26928)
-- Name: detalle_ingresos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detalle_ingresos (
    id bigint NOT NULL,
    idingreso integer NOT NULL,
    idproducto integer NOT NULL,
    cantidad integer NOT NULL,
    precio numeric(11,2) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.detalle_ingresos OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 26927)
-- Name: detalle_ingresos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.detalle_ingresos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.detalle_ingresos_id_seq OWNER TO postgres;

--
-- TOC entry 3520 (class 0 OID 0)
-- Dependencies: 237
-- Name: detalle_ingresos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.detalle_ingresos_id_seq OWNED BY public.detalle_ingresos.id;


--
-- TOC entry 242 (class 1259 OID 26962)
-- Name: detalle_ventas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detalle_ventas (
    id bigint NOT NULL,
    idventa integer NOT NULL,
    idproducto integer NOT NULL,
    cantidad integer NOT NULL,
    precio numeric(11,2) NOT NULL,
    descuento numeric(11,2) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.detalle_ventas OWNER TO postgres;

--
-- TOC entry 241 (class 1259 OID 26961)
-- Name: detalle_ventas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.detalle_ventas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.detalle_ventas_id_seq OWNER TO postgres;

--
-- TOC entry 3521 (class 0 OID 0)
-- Dependencies: 241
-- Name: detalle_ventas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.detalle_ventas_id_seq OWNED BY public.detalle_ventas.id;


--
-- TOC entry 215 (class 1259 OID 26780)
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(191) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO postgres;

--
-- TOC entry 214 (class 1259 OID 26779)
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO postgres;

--
-- TOC entry 3522 (class 0 OID 0)
-- Dependencies: 214
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- TOC entry 236 (class 1259 OID 26911)
-- Name: ingresos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ingresos (
    id bigint NOT NULL,
    idproveedor integer NOT NULL,
    idusuario integer NOT NULL,
    tipo_comprobante character varying(20) NOT NULL,
    serie_comprobante character varying(7),
    num_comprobante character varying(10) NOT NULL,
    fecha timestamp(0) without time zone NOT NULL,
    impuesto numeric(4,2) NOT NULL,
    total numeric(11,2) NOT NULL,
    estado character varying(20) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.ingresos OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 26910)
-- Name: ingresos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ingresos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ingresos_id_seq OWNER TO postgres;

--
-- TOC entry 3523 (class 0 OID 0)
-- Dependencies: 235
-- Name: ingresos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ingresos_id_seq OWNED BY public.ingresos.id;


--
-- TOC entry 210 (class 1259 OID 26631)
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(191) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- TOC entry 209 (class 1259 OID 26630)
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO postgres;

--
-- TOC entry 3524 (class 0 OID 0)
-- Dependencies: 209
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- TOC entry 222 (class 1259 OID 26821)
-- Name: model_has_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.model_has_permissions (
    permission_id bigint NOT NULL,
    model_type character varying(191) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_permissions OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 26832)
-- Name: model_has_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.model_has_roles (
    role_id bigint NOT NULL,
    model_type character varying(191) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_roles OWNER TO postgres;

--
-- TOC entry 213 (class 1259 OID 26775)
-- Name: password_resets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_resets (
    email character varying(191) NOT NULL,
    token character varying(191) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_resets OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 26804)
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(191) NOT NULL,
    guard_name character varying(191) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 26803)
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO postgres;

--
-- TOC entry 3525 (class 0 OID 0)
-- Dependencies: 218
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- TOC entry 228 (class 1259 OID 26868)
-- Name: persona; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.persona (
    id bigint NOT NULL,
    tipo_persona character varying(20) NOT NULL,
    nombre character varying(100) NOT NULL,
    tipo_documento character varying(20),
    num_documento character varying(20),
    direccion character varying(70),
    telefono character varying(20),
    email character varying(50),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.persona OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 26867)
-- Name: persona_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.persona_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.persona_id_seq OWNER TO postgres;

--
-- TOC entry 3526 (class 0 OID 0)
-- Dependencies: 227
-- Name: persona_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.persona_id_seq OWNED BY public.persona.id;


--
-- TOC entry 217 (class 1259 OID 26792)
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(191) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(191) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 26791)
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_access_tokens_id_seq OWNER TO postgres;

--
-- TOC entry 3527 (class 0 OID 0)
-- Dependencies: 216
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- TOC entry 234 (class 1259 OID 26896)
-- Name: productos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.productos (
    id bigint NOT NULL,
    idcategoria integer NOT NULL,
    codigo character varying(50),
    nombre character varying(100) NOT NULL,
    precio_venta numeric(11,2) NOT NULL,
    stock integer NOT NULL,
    descripcion character varying(256),
    estado boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.productos OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 26895)
-- Name: productos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.productos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.productos_id_seq OWNER TO postgres;

--
-- TOC entry 3528 (class 0 OID 0)
-- Dependencies: 233
-- Name: productos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.productos_id_seq OWNED BY public.productos.id;


--
-- TOC entry 224 (class 1259 OID 26843)
-- Name: role_has_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_has_permissions (
    permission_id bigint NOT NULL,
    role_id bigint NOT NULL
);


ALTER TABLE public.role_has_permissions OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 26813)
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(191) NOT NULL,
    guard_name character varying(191) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 26812)
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO postgres;

--
-- TOC entry 3529 (class 0 OID 0)
-- Dependencies: 220
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- TOC entry 212 (class 1259 OID 26763)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(191) NOT NULL,
    email character varying(191) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(191) NOT NULL,
    estilo character varying(191) DEFAULT 'normal'::character varying NOT NULL,
    fuente character varying(191) DEFAULT 'img/perfil/logo_v1.png'::character varying NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 211 (class 1259 OID 26762)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- TOC entry 3530 (class 0 OID 0)
-- Dependencies: 211
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 240 (class 1259 OID 26945)
-- Name: ventas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventas (
    id bigint NOT NULL,
    idcliente integer NOT NULL,
    idusuario integer NOT NULL,
    tipo_comprobante character varying(20) NOT NULL,
    serie_comprobante character varying(7),
    num_comprobante character varying(10) NOT NULL,
    fecha_hora timestamp(0) without time zone NOT NULL,
    impuesto numeric(4,2) NOT NULL,
    total numeric(11,2) NOT NULL,
    estado character varying(20) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.ventas OWNER TO postgres;

--
-- TOC entry 239 (class 1259 OID 26944)
-- Name: ventas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ventas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ventas_id_seq OWNER TO postgres;

--
-- TOC entry 3531 (class 0 OID 0)
-- Dependencies: 239
-- Name: ventas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ventas_id_seq OWNED BY public.ventas.id;


--
-- TOC entry 3259 (class 2604 OID 26862)
-- Name: blogs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blogs ALTER COLUMN id SET DEFAULT nextval('public.blogs_id_seq'::regclass);


--
-- TOC entry 3262 (class 2604 OID 26889)
-- Name: categorias id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias ALTER COLUMN id SET DEFAULT nextval('public.categorias_id_seq'::regclass);


--
-- TOC entry 3261 (class 2604 OID 26878)
-- Name: cotacto id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotacto ALTER COLUMN id SET DEFAULT nextval('public.cotacto_id_seq'::regclass);


--
-- TOC entry 3267 (class 2604 OID 26931)
-- Name: detalle_ingresos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle_ingresos ALTER COLUMN id SET DEFAULT nextval('public.detalle_ingresos_id_seq'::regclass);


--
-- TOC entry 3269 (class 2604 OID 26965)
-- Name: detalle_ventas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle_ventas ALTER COLUMN id SET DEFAULT nextval('public.detalle_ventas_id_seq'::regclass);


--
-- TOC entry 3254 (class 2604 OID 26783)
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- TOC entry 3266 (class 2604 OID 26914)
-- Name: ingresos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingresos ALTER COLUMN id SET DEFAULT nextval('public.ingresos_id_seq'::regclass);


--
-- TOC entry 3250 (class 2604 OID 26634)
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- TOC entry 3257 (class 2604 OID 26807)
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- TOC entry 3260 (class 2604 OID 26871)
-- Name: persona id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona ALTER COLUMN id SET DEFAULT nextval('public.persona_id_seq'::regclass);


--
-- TOC entry 3256 (class 2604 OID 26795)
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- TOC entry 3264 (class 2604 OID 26899)
-- Name: productos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productos ALTER COLUMN id SET DEFAULT nextval('public.productos_id_seq'::regclass);


--
-- TOC entry 3258 (class 2604 OID 26816)
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- TOC entry 3251 (class 2604 OID 26766)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 3268 (class 2604 OID 26948)
-- Name: ventas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventas ALTER COLUMN id SET DEFAULT nextval('public.ventas_id_seq'::regclass);


--
-- TOC entry 3495 (class 0 OID 26859)
-- Dependencies: 226
-- Data for Name: blogs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blogs (id, titulo, contenido, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3501 (class 0 OID 26886)
-- Dependencies: 232
-- Data for Name: categorias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categorias (id, nombre, descripcion, estado, created_at, updated_at) FROM stdin;
1	cuaderno	empastados y anillados	t	2023-06-20 18:56:59	2023-06-20 19:03:57
2	libros	libros de lectura, escritura, obras	t	2023-06-22 12:27:55	2023-06-22 12:27:55
3	lapiceros	lapiceros marcadores, lapices	t	2023-06-22 12:28:47	2023-06-22 12:28:47
4	regla	reglas de plastico, metalicas,de madera	t	2023-06-22 12:29:06	2023-06-22 12:29:06
5	goma eva	sensilla atoallada, com brillo,cromada,d3,estampada	t	2023-06-22 12:29:22	2023-06-22 12:29:22
6	forros	forros lustre,araña asebrada,con puntos, animalprint	t	2023-06-22 12:29:41	2023-06-22 12:29:41
7	colores	colores grandes y pequenos de diferentes cantidades y marcas	t	2023-06-22 12:29:55	2023-06-22 12:29:55
8	material de escritorio	lo que coresponde a gomas,tajadores,pisapapel,etc	t	2023-06-22 12:30:23	2023-06-22 12:30:23
9	plastofor	en plancha, esferas ,etc	t	2023-06-22 12:30:39	2023-06-22 12:30:39
10	tela	por metro tergal, razo, lienso, popelina, etc	t	2023-06-22 12:30:51	2023-06-22 12:30:51
\.


--
-- TOC entry 3499 (class 0 OID 26875)
-- Dependencies: 230
-- Data for Name: cotacto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cotacto (id, nombre, email, telefono, mensaje, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3507 (class 0 OID 26928)
-- Dependencies: 238
-- Data for Name: detalle_ingresos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detalle_ingresos (id, idingreso, idproducto, cantidad, precio, created_at, updated_at) FROM stdin;
1	2	1	10	15.00	2023-06-21 05:11:38	2023-06-21 05:11:38
\.


--
-- TOC entry 3511 (class 0 OID 26962)
-- Dependencies: 242
-- Data for Name: detalle_ventas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detalle_ventas (id, idventa, idproducto, cantidad, precio, descuento, created_at, updated_at) FROM stdin;
3	5	1	2	12.00	0.00	2023-06-21 03:54:43	2023-06-21 03:54:43
4	6	2	1	17.00	0.00	2023-06-22 14:18:58	2023-06-22 14:18:58
5	7	2	5	17.00	0.00	2023-06-22 14:33:47	2023-06-22 14:33:47
\.


--
-- TOC entry 3484 (class 0 OID 26780)
-- Dependencies: 215
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- TOC entry 3505 (class 0 OID 26911)
-- Dependencies: 236
-- Data for Name: ingresos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ingresos (id, idproveedor, idusuario, tipo_comprobante, serie_comprobante, num_comprobante, fecha, impuesto, total, estado, created_at, updated_at) FROM stdin;
1	1	1	sin comprobante	\N	000000	2023-06-21 05:10:45	0.00	0.00	Pendiente	2023-06-21 05:10:45	2023-06-21 05:10:45
2	1	1	sin comprobante	\N	000000	2023-06-21 05:11:38	0.00	150.00	Concluido	2023-06-21 05:11:38	2023-06-21 05:11:38
\.


--
-- TOC entry 3479 (class 0 OID 26631)
-- Dependencies: 210
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, migration, batch) FROM stdin;
9	2014_10_12_000000_create_users_table	1
10	2014_10_12_100000_create_password_resets_table	1
11	2019_08_19_000000_create_failed_jobs_table	1
12	2019_12_14_000001_create_personal_access_tokens_table	1
13	2023_04_05_002259_create_permission_tables	1
14	2023_04_05_003638_create_blogs_table	1
15	2023_05_24_215722_create_persona_table	1
16	2023_06_07_235719_create_cotacto_table	1
17	2023_06_20_174517_create_categorias_table	1
18	2023_06_20_174615_create_productos_table	1
19	2023_06_20_174618_create_ingresos_table	1
20	2023_06_20_174621_create_detalle_ingresos_table	1
21	2023_06_20_174624_create_ventas_table	1
22	2023_06_20_174627_create_detalle_ventas_table	1
\.


--
-- TOC entry 3491 (class 0 OID 26821)
-- Dependencies: 222
-- Data for Name: model_has_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.model_has_permissions (permission_id, model_type, model_id) FROM stdin;
\.


--
-- TOC entry 3492 (class 0 OID 26832)
-- Dependencies: 223
-- Data for Name: model_has_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.model_has_roles (role_id, model_type, model_id) FROM stdin;
1	App\\Models\\User	1
\.


--
-- TOC entry 3482 (class 0 OID 26775)
-- Dependencies: 213
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_resets (email, token, created_at) FROM stdin;
\.


--
-- TOC entry 3488 (class 0 OID 26804)
-- Dependencies: 219
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (id, name, guard_name, created_at, updated_at) FROM stdin;
1	ver-rol	web	2023-06-20 18:01:39	2023-06-20 18:01:39
2	crear-rol	web	2023-06-20 18:01:39	2023-06-20 18:01:39
3	editar-rol	web	2023-06-20 18:01:39	2023-06-20 18:01:39
4	borrar-rol	web	2023-06-20 18:01:39	2023-06-20 18:01:39
5	ver-user	web	2023-06-20 18:01:39	2023-06-20 18:01:39
6	crear-user	web	2023-06-20 18:01:39	2023-06-20 18:01:39
7	editar-user	web	2023-06-20 18:01:39	2023-06-20 18:01:39
8	borrar-user	web	2023-06-20 18:01:39	2023-06-20 18:01:39
9	ver-blog	web	2023-06-20 18:01:39	2023-06-20 18:01:39
10	crear-blog	web	2023-06-20 18:01:39	2023-06-20 18:01:39
11	editar-blog	web	2023-06-20 18:01:39	2023-06-20 18:01:39
12	borrar-blog	web	2023-06-20 18:01:39	2023-06-20 18:01:39
13	ver-persona	web	2023-06-20 18:01:39	2023-06-20 18:01:39
14	crear-persona	web	2023-06-20 18:01:39	2023-06-20 18:01:39
15	editar-persona	web	2023-06-20 18:01:39	2023-06-20 18:01:39
16	borrar-persona	web	2023-06-20 18:01:39	2023-06-20 18:01:39
17	ver-producto	web	2023-06-20 18:01:39	2023-06-20 18:01:39
18	crear-producto	web	2023-06-20 18:01:39	2023-06-20 18:01:39
19	editar-producto	web	2023-06-20 18:01:39	2023-06-20 18:01:39
20	borrar-producto	web	2023-06-20 18:01:39	2023-06-20 18:01:39
21	ver-venta	web	2023-06-20 18:01:39	2023-06-20 18:01:39
22	crear-venta	web	2023-06-20 18:01:39	2023-06-20 18:01:39
23	editar-venta	web	2023-06-20 18:01:39	2023-06-20 18:01:39
24	borrar-venta	web	2023-06-20 18:01:39	2023-06-20 18:01:39
25	ver-ingreso	web	2023-06-20 18:01:39	2023-06-20 18:01:39
26	crear-ingreso	web	2023-06-20 18:01:39	2023-06-20 18:01:39
27	editar-ingreso	web	2023-06-20 18:01:39	2023-06-20 18:01:39
28	borrar-ingreso	web	2023-06-20 18:01:39	2023-06-20 18:01:39
29	ver-categoria	web	2023-06-20 18:01:39	2023-06-20 18:01:39
30	crear-categoria	web	2023-06-20 18:01:39	2023-06-20 18:01:39
31	editar-categoria	web	2023-06-20 18:01:39	2023-06-20 18:01:39
32	borrar-categoria	web	2023-06-20 18:01:39	2023-06-20 18:01:39
\.


--
-- TOC entry 3497 (class 0 OID 26868)
-- Dependencies: 228
-- Data for Name: persona; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.persona (id, tipo_persona, nombre, tipo_documento, num_documento, direccion, telefono, email, created_at, updated_at) FROM stdin;
2	Cliente	migelina	\N	\N	\N	\N	\N	2023-06-20 19:38:50	2023-06-20 19:38:50
1	Proveedor	don choco	\N	\N	\N	7654321	\N	2023-06-20 18:33:57	2023-06-21 04:54:47
3	Cliente	narda	ci	7654321	\N	\N	\N	2023-06-22 14:28:58	2023-06-22 14:28:58
4	Cliente	marina	\N	\N	\N	\N	\N	2023-06-22 14:29:16	2023-06-22 14:29:16
5	Proveedor	Dña Carlita	\N	\N	\N	\N	\N	2023-06-22 14:29:40	2023-06-22 14:29:40
6	Proveedor	Charo	\N	\N	\N	\N	\N	2023-06-22 14:30:05	2023-06-22 14:30:05
\.


--
-- TOC entry 3486 (class 0 OID 26792)
-- Dependencies: 217
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3503 (class 0 OID 26896)
-- Dependencies: 234
-- Data for Name: productos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.productos (id, idcategoria, codigo, nombre, precio_venta, stock, descripcion, estado, created_at, updated_at) FROM stdin;
1	1	0001	espiran 1/2 of win, 100 hj	12.00	57	espiran de medio oficio de 100 hojas marca winer	t	2023-06-20 19:24:43	2023-06-21 05:11:38
3	1	C0001	espiral oficio 100 hj	18.00	0	espiral de 100 hojas tamaño oficio	t	2023-06-22 13:46:26	2023-06-22 13:46:26
2	7	0002	colores	17.00	34	fabercaster de 12 unidades	t	2023-06-20 19:53:59	2023-06-22 14:33:47
\.


--
-- TOC entry 3493 (class 0 OID 26843)
-- Dependencies: 224
-- Data for Name: role_has_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_has_permissions (permission_id, role_id) FROM stdin;
1	1
2	1
3	1
4	1
5	1
6	1
7	1
8	1
9	1
10	1
11	1
12	1
13	1
14	1
15	1
16	1
17	1
18	1
19	1
20	1
21	1
22	1
23	1
24	1
25	1
26	1
27	1
28	1
29	1
30	1
31	1
32	1
\.


--
-- TOC entry 3490 (class 0 OID 26813)
-- Dependencies: 221
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, guard_name, created_at, updated_at) FROM stdin;
1	root	web	2023-06-20 18:01:57	2023-06-20 18:01:57
\.


--
-- TOC entry 3481 (class 0 OID 26763)
-- Dependencies: 212
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, email_verified_at, password, estilo, fuente, remember_token, created_at, updated_at) FROM stdin;
1	Ad min	admin@gmail.com	\N	$2y$10$G.MHo0nz/1k3PU0ReVz2luST4srWqLPWLkxUJEKAmt9IHjklbOcfm	normal	img/perfil/logo_v1.png	\N	2023-06-20 18:01:57	2023-06-21 04:02:42
\.


--
-- TOC entry 3509 (class 0 OID 26945)
-- Dependencies: 240
-- Data for Name: ventas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventas (id, idcliente, idusuario, tipo_comprobante, serie_comprobante, num_comprobante, fecha_hora, impuesto, total, estado, created_at, updated_at) FROM stdin;
4	2	1	sin comprobante	\N	000000	2023-06-21 02:37:34	0.00	0.00	Pendiente	2023-06-21 02:37:34	2023-06-21 02:37:34
5	2	1	sin comprobante	\N	000000	2023-06-21 02:38:26	0.00	24.00	Concluido	2023-06-21 02:38:26	2023-06-21 03:54:43
6	2	1	sin comprobante	\N	000000	2023-06-22 14:18:58	0.00	17.00	Concluido	2023-06-22 14:18:58	2023-06-22 14:18:58
7	3	1	sin comprobante	\N	000000	2023-06-22 14:33:47	0.00	85.00	Concluido	2023-06-22 14:33:47	2023-06-22 14:33:47
\.


--
-- TOC entry 3532 (class 0 OID 0)
-- Dependencies: 225
-- Name: blogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blogs_id_seq', 1, false);


--
-- TOC entry 3533 (class 0 OID 0)
-- Dependencies: 231
-- Name: categorias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categorias_id_seq', 10, true);


--
-- TOC entry 3534 (class 0 OID 0)
-- Dependencies: 229
-- Name: cotacto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cotacto_id_seq', 1, false);


--
-- TOC entry 3535 (class 0 OID 0)
-- Dependencies: 237
-- Name: detalle_ingresos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.detalle_ingresos_id_seq', 1, true);


--
-- TOC entry 3536 (class 0 OID 0)
-- Dependencies: 241
-- Name: detalle_ventas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.detalle_ventas_id_seq', 5, true);


--
-- TOC entry 3537 (class 0 OID 0)
-- Dependencies: 214
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- TOC entry 3538 (class 0 OID 0)
-- Dependencies: 235
-- Name: ingresos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ingresos_id_seq', 2, true);


--
-- TOC entry 3539 (class 0 OID 0)
-- Dependencies: 209
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 22, true);


--
-- TOC entry 3540 (class 0 OID 0)
-- Dependencies: 218
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.permissions_id_seq', 32, true);


--
-- TOC entry 3541 (class 0 OID 0)
-- Dependencies: 227
-- Name: persona_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.persona_id_seq', 6, true);


--
-- TOC entry 3542 (class 0 OID 0)
-- Dependencies: 216
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- TOC entry 3543 (class 0 OID 0)
-- Dependencies: 233
-- Name: productos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.productos_id_seq', 3, true);


--
-- TOC entry 3544 (class 0 OID 0)
-- Dependencies: 220
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, true);


--
-- TOC entry 3545 (class 0 OID 0)
-- Dependencies: 211
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- TOC entry 3546 (class 0 OID 0)
-- Dependencies: 239
-- Name: ventas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ventas_id_seq', 7, true);


--
-- TOC entry 3303 (class 2606 OID 26866)
-- Name: blogs blogs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blogs
    ADD CONSTRAINT blogs_pkey PRIMARY KEY (id);


--
-- TOC entry 3311 (class 2606 OID 26894)
-- Name: categorias categorias_nombre_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_nombre_unique UNIQUE (nombre);


--
-- TOC entry 3313 (class 2606 OID 26892)
-- Name: categorias categorias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY (id);


--
-- TOC entry 3307 (class 2606 OID 26884)
-- Name: cotacto cotacto_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotacto
    ADD CONSTRAINT cotacto_email_unique UNIQUE (email);


--
-- TOC entry 3309 (class 2606 OID 26882)
-- Name: cotacto cotacto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotacto
    ADD CONSTRAINT cotacto_pkey PRIMARY KEY (id);


--
-- TOC entry 3321 (class 2606 OID 26933)
-- Name: detalle_ingresos detalle_ingresos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle_ingresos
    ADD CONSTRAINT detalle_ingresos_pkey PRIMARY KEY (id);


--
-- TOC entry 3325 (class 2606 OID 26967)
-- Name: detalle_ventas detalle_ventas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle_ventas
    ADD CONSTRAINT detalle_ventas_pkey PRIMARY KEY (id);


--
-- TOC entry 3278 (class 2606 OID 26788)
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- TOC entry 3280 (class 2606 OID 26790)
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- TOC entry 3319 (class 2606 OID 26916)
-- Name: ingresos ingresos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingresos
    ADD CONSTRAINT ingresos_pkey PRIMARY KEY (id);


--
-- TOC entry 3271 (class 2606 OID 26636)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3296 (class 2606 OID 26831)
-- Name: model_has_permissions model_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_pkey PRIMARY KEY (permission_id, model_id, model_type);


--
-- TOC entry 3299 (class 2606 OID 26842)
-- Name: model_has_roles model_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_pkey PRIMARY KEY (role_id, model_id, model_type);


--
-- TOC entry 3287 (class 2606 OID 26811)
-- Name: permissions permissions_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_guard_name_unique UNIQUE (name, guard_name);


--
-- TOC entry 3289 (class 2606 OID 26809)
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3305 (class 2606 OID 26873)
-- Name: persona persona_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT persona_pkey PRIMARY KEY (id);


--
-- TOC entry 3282 (class 2606 OID 26799)
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3284 (class 2606 OID 26802)
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- TOC entry 3315 (class 2606 OID 26909)
-- Name: productos productos_nombre_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_nombre_unique UNIQUE (nombre);


--
-- TOC entry 3317 (class 2606 OID 26902)
-- Name: productos productos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_pkey PRIMARY KEY (id);


--
-- TOC entry 3301 (class 2606 OID 26857)
-- Name: role_has_permissions role_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_pkey PRIMARY KEY (permission_id, role_id);


--
-- TOC entry 3291 (class 2606 OID 26820)
-- Name: roles roles_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_guard_name_unique UNIQUE (name, guard_name);


--
-- TOC entry 3293 (class 2606 OID 26818)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 3273 (class 2606 OID 26774)
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- TOC entry 3275 (class 2606 OID 26772)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3323 (class 2606 OID 26950)
-- Name: ventas ventas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_pkey PRIMARY KEY (id);


--
-- TOC entry 3294 (class 1259 OID 26824)
-- Name: model_has_permissions_model_id_model_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX model_has_permissions_model_id_model_type_index ON public.model_has_permissions USING btree (model_id, model_type);


--
-- TOC entry 3297 (class 1259 OID 26835)
-- Name: model_has_roles_model_id_model_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX model_has_roles_model_id_model_type_index ON public.model_has_roles USING btree (model_id, model_type);


--
-- TOC entry 3276 (class 1259 OID 26778)
-- Name: password_resets_email_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX password_resets_email_index ON public.password_resets USING btree (email);


--
-- TOC entry 3285 (class 1259 OID 26800)
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- TOC entry 3333 (class 2606 OID 26934)
-- Name: detalle_ingresos detalle_ingresos_idingreso_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle_ingresos
    ADD CONSTRAINT detalle_ingresos_idingreso_foreign FOREIGN KEY (idingreso) REFERENCES public.ingresos(id) ON DELETE CASCADE;


--
-- TOC entry 3334 (class 2606 OID 26939)
-- Name: detalle_ingresos detalle_ingresos_idproducto_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle_ingresos
    ADD CONSTRAINT detalle_ingresos_idproducto_foreign FOREIGN KEY (idproducto) REFERENCES public.productos(id);


--
-- TOC entry 3338 (class 2606 OID 26973)
-- Name: detalle_ventas detalle_ventas_idproducto_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle_ventas
    ADD CONSTRAINT detalle_ventas_idproducto_foreign FOREIGN KEY (idproducto) REFERENCES public.productos(id);


--
-- TOC entry 3337 (class 2606 OID 26968)
-- Name: detalle_ventas detalle_ventas_idventa_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle_ventas
    ADD CONSTRAINT detalle_ventas_idventa_foreign FOREIGN KEY (idventa) REFERENCES public.ventas(id) ON DELETE CASCADE;


--
-- TOC entry 3331 (class 2606 OID 26917)
-- Name: ingresos ingresos_idproveedor_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingresos
    ADD CONSTRAINT ingresos_idproveedor_foreign FOREIGN KEY (idproveedor) REFERENCES public.persona(id);


--
-- TOC entry 3332 (class 2606 OID 26922)
-- Name: ingresos ingresos_idusuario_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingresos
    ADD CONSTRAINT ingresos_idusuario_foreign FOREIGN KEY (idusuario) REFERENCES public.users(id);


--
-- TOC entry 3326 (class 2606 OID 26825)
-- Name: model_has_permissions model_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- TOC entry 3327 (class 2606 OID 26836)
-- Name: model_has_roles model_has_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- TOC entry 3330 (class 2606 OID 26903)
-- Name: productos productos_idcategoria_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_idcategoria_foreign FOREIGN KEY (idcategoria) REFERENCES public.categorias(id);


--
-- TOC entry 3328 (class 2606 OID 26846)
-- Name: role_has_permissions role_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- TOC entry 3329 (class 2606 OID 26851)
-- Name: role_has_permissions role_has_permissions_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- TOC entry 3335 (class 2606 OID 26951)
-- Name: ventas ventas_idcliente_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_idcliente_foreign FOREIGN KEY (idcliente) REFERENCES public.persona(id);


--
-- TOC entry 3336 (class 2606 OID 26956)
-- Name: ventas ventas_idusuario_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_idusuario_foreign FOREIGN KEY (idusuario) REFERENCES public.users(id);


-- Completed on 2023-06-22 15:43:45

--
-- PostgreSQL database dump complete
--

