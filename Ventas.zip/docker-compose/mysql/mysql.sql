
--Tabla categoría
-- Creación de la tabla categorias
CREATE TABLE categorias (
    id INT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    descripcion VARCHAR(256),
    estado BOOLEAN DEFAULT TRUE NOT NULL,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

-- Creación de la tabla productos
CREATE TABLE productos (
    id INT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    idcategoria INT NOT NULL,
    descripcion VARCHAR(256),
    imagen VARCHAR(256),
    stock INT NOT NULL,
    precio_venta DECIMAL(11,2) NOT NULL,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    FOREIGN KEY (idcategoria) REFERENCES categorias (id)
);


--Tabla persona
create table persona(
       id integer primary key identity,
       tipo_persona varchar(20) not null,
       nombre varchar(100) not null,
       tipo_documento varchar(20) null,
       num_documento varchar(20) null,
       direccion varchar(70) null,
       telefono varchar(20) null,
       email varchar(50) null,
       created_at TIMESTAMP,
       updated_at TIMESTAMP
);



--Tabla rol
create table rol(
       idrol integer primary key identity,
       nombre varchar(30) not null,
       descripcion varchar(100) null,
       estado bit default(1)
           created_at TIMESTAMP,
    updated_at TIMESTAMP,

);

--Tabla usuario
create table usuario(
       id integer primary key identity,
       idrol integer not null,
       nombre varchar(100) not null,
       tipo_documento varchar(20) null,
       num_documento varchar(20) null,
       direccion varchar(70) null,
       telefono varchar(20) null,
       email varchar(50) not null,
       password varbinary not null,
       estado bit default(1),
           created_at TIMESTAMP,
    updated_at TIMESTAMP,

       FOREIGN KEY (idrol) REFERENCES rol (idrol)
);

--Tabla ingreso
create table ingreso(
       idingreso integer primary key identity,
       idproveedor integer not null,
       idusuario integer not null,
       tipo_comprobante varchar(20) not null,
       serie_comprobante varchar(7) null,
       num_comprobante varchar (10) not null,
       fecha datetime not null,
       impuesto decimal (4,2) not null,
       total decimal (11,2) not null,
       estado varchar(20) not null,
           created_at TIMESTAMP,
    updated_at TIMESTAMP,

       FOREIGN KEY (idproveedor) REFERENCES persona (id),
       FOREIGN KEY (idusuario) REFERENCES usuario (idusuario)
);

--Tabla detalle_ingreso
create table detalle_ingreso(
       iddetalle_ingreso integer primary key identity,
       idingreso integer not null,
       idproducto integer not null,
       cantidad integer not null,
       precio decimal(11,2) not null,
           created_at TIMESTAMP,
    updated_at TIMESTAMP,

       FOREIGN KEY (idingreso) REFERENCES ingreso (idingreso) ON DELETE CASCADE,
       FOREIGN KEY (idproducto) REFERENCES producto (idproducto)
);


--Tabla venta
create table venta(
       idventa integer primary key identity,
       idcliente integer not null,
       idusuario integer not null,
       tipo_comprobante varchar(20) not null,
       serie_comprobante varchar(7) null,
       num_comprobante varchar (10) not null,
       fecha_hora datetime not null,
       impuesto decimal (4,2) not null,
       total decimal (11,2) not null,
       estado varchar(20) not null,
           created_at TIMESTAMP,
    updated_at TIMESTAMP,

       FOREIGN KEY (idcliente) REFERENCES persona (id),
       FOREIGN KEY (idusuario) REFERENCES usuario (idusuario)
);

--Tabla detalle_venta
create table detalle_venta(
       iddetalle_venta integer primary key identity,
       idventa integer not null,
       idproducto integer not null,
       cantidad integer not null,
       precio decimal(11,2) not null,
       descuento decimal(11,2) not null,
           created_at TIMESTAMP,
    updated_at TIMESTAMP,

       FOREIGN KEY (idventa) REFERENCES venta (idventa) ON DELETE CASCADE,
       FOREIGN KEY (idproducto) REFERENCES producto (idproducto)
);


insert into categoria (nombre,descripcion) values ('libros','libros de lectura, escritura, obras');
insert into categoria (nombre,descripcion) values ('cuadernos','cuadernos anillados, empastados, libretas');
insert into categoria (nombre,descripcion) values ('lapiceros','lapiceros marcadores, lapices');
insert into categoria (nombre,descripcion) values ('reglas','reglas de plastico, metalicas,de madera');
insert into categoria (nombre,descripcion) values ('coma eva','sensilla atoallada, com brillo,cromada,d3,estampada');
insert into categoria (nombre,descripcion) values ('forros','forros lustre,araña asebrada,con puntos, animalprint');
insert into categoria (nombre,descripcion) values ('colores','colores grandes y pequenos de diferentes cantidades y marcas');
insert into categoria (nombre,descripcion) values ('material de escritorio','lo que coresponde a gomas,tajadores,pisapapel,etc');
insert into categoria (nombre,descripcion) values ('plastofor','en plancha, esferas ,etc');
insert into categoria (nombre,descripcion) values ('tela','por metro tergal, razo, lienso, popelina, etc');
select * from categoria;


--porductos libros
insert into categoria (idcategoria,codigo,nombre,precio_venta,stock,descripcion,estado ) values (1,'lib-001','alma de niño 1',25,15,'libro de lecttura para niños de primero basico',1);


