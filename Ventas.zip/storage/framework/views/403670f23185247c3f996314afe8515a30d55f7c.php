<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Productos</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-producto')): ?>
                            <a class="btn btn-warning" href="<?php echo e(route('productos.create')); ?>"> Nuevo </a>
                        <?php endif; ?>


                            <table id="data-table" class = "table table-striped mt-2">
                                <thead >
                                    <th>ID</th>
                                    <th>Categoría</th>
                                    <th>Código</th>
                                    <th>Nombre</th>
                                    <th>Precio Venta</th>
                                    <th>Stock</th>
                                    <th>Descripción</th>
                                    <th>Estado</th>
                                    <th> Acciones</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($producto->id); ?></td>
                                        <td><?php echo e($producto->categoria->nombre); ?></td>
                                        <td><?php echo e($producto->codigo); ?></td>
                                        <td><?php echo e($producto->nombre); ?></td>
                                        <td><?php echo e($producto->precio_venta); ?></td>
                                        <td><?php echo e($producto->stock); ?></td>
                                        <td><?php echo e($producto->descripcion); ?></td>
                                        <td><?php echo e($producto->estado); ?></td>
                                        <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-producto')): ?>
                                            <a class = "btn btn-info" href="<?php echo e(route('productos.edit',$producto->id)); ?>"> Editar </a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-producto')): ?>
                                            <?php echo Form::open(['method' => 'DELETE','route' => ['productos.destroy', $producto->id],'style'=>'display:inline']); ?>

                                                <?php echo Form::submit('borrar', ['class'=>'btn btn-danger']); ?>

                                            <?php echo Form::close(); ?>

                                        <?php endif; ?>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="pagination justify-content-end">
                                <?php echo $productos->links(); ?>

                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ingenieria en Software II\Segundo Parcial\Ventas\resources\views/productos/index.blade.php ENDPATH**/ ?>