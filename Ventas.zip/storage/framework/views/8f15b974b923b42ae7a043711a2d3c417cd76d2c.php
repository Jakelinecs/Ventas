<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Alta de Personas</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-dark alert-dismissible fade show" role="alert">
                                    <strong>!Revise los campos!</strong>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge badge-danger"><?php echo e($error); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <button type= "button" class="close" data-dismiss="alert" aria-label="close">
                                        <span aria-hidden="true">$times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>

                            <?php echo Form::open(array('route'=>'personas.store', 'method'=>'POST')); ?>

                            <div class="row">


                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <label for="nombre">Nombre</label>
                                        <?php echo Form::text('nombre',null,array('class'=>'form-control')); ?>

                                    </div>
                                </div>


                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <label for="tipo_persona">Tipo de persona</label>
                                        <?php echo Form::select('tipo_persona', ['Cliente' => 'Cliente', 'Proveedor' => 'Proveedor'], null, ['class' => 'form-control']); ?>

                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <label for="tipo_documento">tipo de documento</label>
                                        <?php echo Form::text('tipo_documento',null,array('class'=>'form-control')); ?>

                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <label for="num_documento">Numero   de documento</label>
                                        <?php echo Form::text('num_documento',null,array('class'=>'form-control')); ?>

                                    </div>
                                </div>


                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <label for="direccion">Direccion</label>
                                        <?php echo Form::text('direccion',null,array('class'=>'form-control')); ?>

                                    </div>
                                </div>


                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <label for="telefono">telefono</label>
                                        <?php echo Form::text('telefono',null,array('class'=>'form-control')); ?>

                                    </div>
                                </div>


                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <?php echo Form::text('email',null,array('class'=>'form-control','id'=>'email', 'type'=>'email')); ?>

                                    </div>
                                </div>




                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                </div>

                            </div>

                            <?php echo Form::close(); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ingenieria en Software II\Segundo Parcial\Ventas\resources\views/personas/crear.blade.php ENDPATH**/ ?>