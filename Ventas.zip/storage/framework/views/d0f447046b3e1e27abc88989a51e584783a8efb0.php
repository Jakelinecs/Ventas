<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Ventas</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-venta')): ?>
                            <a class="btn btn-warning" href="<?php echo e(route('ventas.create')); ?>"> Nuevo </a>
                        <?php endif; ?>


                            <table id="data-table" class = "table table-striped mt-2">
                                <thead >
                                    <th>ID</th>
                                    <th>Cliente</th>
                                    <th>Fecha</th>
                                    <th>Total</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($venta->id); ?></th>
                                        <th><?php echo e($venta->idcliente); ?></th>
                                        <th><?php echo e($venta->fecha_hora); ?></th>
                                        <th><?php echo e($venta->total); ?></th>
                                        <th><?php echo e($venta->estado); ?></th>
                                        <td>
                                        <a href="<?php echo e(route('ventas.show', $venta->id)); ?>" class="btn btn-info">Ver</a>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-venta')): ?>
                                            <a class = "btn btn-info" href="<?php echo e(route('ventas.edit',$venta->id)); ?>"> Editar </a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-venta')): ?>
                                            <?php echo Form::open(['method' => 'DELETE','route' => ['ventas.destroy', $venta->id],'style'=>'display:inline']); ?>

                                                <?php echo Form::submit('borrar', ['class'=>'btn btn-danger']); ?>

                                            <?php echo Form::close(); ?>

                                        <?php endif; ?>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="pagination justify-content-end">
                                <?php echo $ventas->links(); ?>

                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ingenieria en Software II\Segundo Parcial\Ventas\resources\views/ventas/index.blade.php ENDPATH**/ ?>