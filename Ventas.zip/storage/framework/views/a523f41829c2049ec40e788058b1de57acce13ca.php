<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Ingreso de Mercaderia</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-ingreso')): ?>
                            <a class="btn btn-warning" href="<?php echo e(route('ingresos.create')); ?>"> Nuevo </a>
                        <?php endif; ?>


                            <table id="data-table" class = "table table-striped mt-2">
                                <thead >
                                    <th>ID</th>
                                    <th>Proveedor</th>
                                    <th>Fecha</th>
                                    <th>Total</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $ingresos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingreso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($ingreso->id); ?></th>
                                        <th><?php echo e($ingreso->idproveedor); ?></th>
                                        <th><?php echo e($ingreso->fecha); ?></th>
                                        <th><?php echo e($ingreso->total); ?></th>
                                        <th><?php echo e($ingreso->estado); ?></th>
                                        <td>
                                        <a href="<?php echo e(route('ingresos.show', $ingreso->id)); ?>" class="btn btn-info">Ver</a>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-ingreso')): ?>
                                            <a class = "btn btn-info" href="<?php echo e(route('ingresos.edit',$ingreso->id)); ?>"> Editar </a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-ingreso')): ?>
                                            <?php echo Form::open(['method' => 'DELETE','route' => ['ingresos.destroy', $ingreso->id],'style'=>'display:inline']); ?>

                                                <?php echo Form::submit('borrar', ['class'=>'btn btn-danger']); ?>

                                            <?php echo Form::close(); ?>

                                        <?php endif; ?>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="pagination justify-content-end">
                                <?php echo $ingresos->links(); ?>

                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ingenieria en Software II\Segundo Parcial\Ventas\resources\views/ingresos/index.blade.php ENDPATH**/ ?>