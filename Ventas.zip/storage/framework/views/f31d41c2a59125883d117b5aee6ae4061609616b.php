<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\tecnologia web\1-2023\proyecto\Veterinaria\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>