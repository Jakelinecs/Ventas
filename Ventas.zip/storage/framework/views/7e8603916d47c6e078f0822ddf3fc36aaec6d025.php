<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Editar</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                    <div class="container">
        <h1>Detalles de la Venta</h1>
        <hr>

        <div class="row">
            <div class="col-md-6">
                <h3>Información de la Venta</h3>
                <p><strong>ID:</strong> <?php echo e($venta->id); ?></p>
                <p><strong>Usuario:</strong> <?php echo e($usuario); ?></p>
                <p><strong>Cliente:</strong> <?php echo e($cliente); ?></p>
                <p><strong>Tipo de Comprobante:</strong> <?php echo e($venta->tipo_comprobante); ?></p>
                <p><strong>Número de Comprobante:</strong> <?php echo e($venta->num_comprobante); ?></p>
                <p><strong>Fecha y Hora:</strong> <?php echo e($venta->fecha_hora); ?></p>
                <p><strong>Impuesto:</strong> <?php echo e($venta->impuesto); ?></p>
                <p><strong>Total:</strong> <?php echo e($venta->total); ?></p>
                <p><strong>Estado:</strong> <?php echo e($venta->estado); ?></p>
            </div>

            <div class="col-md-6">
                <h3>Detalles de la Venta</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Precio</th>
                            <th>Descuento</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($detalle->idproducto); ?></td>
                                <td><?php echo e($detalle->cantidad); ?></td>
                                <td><?php echo e($detalle->precio); ?></td>
                                <td><?php echo e($detalle->descuento); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\calidad\proyecto\Ventas\resources\views/ventas/show.blade.php ENDPATH**/ ?>